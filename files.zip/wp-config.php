<?php


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'seal_house091236290118');

/** MySQL database username */
define('DB_USER', '561_media');

/** MySQL database password */
define('DB_PASSWORD', '561_media');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'Ja%:-XgOI{:(>|Bb$W6%f%{:[mAfa{SFR8Roku(Tu#$aHZW+VPzobR_zHPsrbA.-');
define('SECURE_AUTH_KEY',  'E#FE+a_g<HmSK]N:8 PZ}G[c> v#R[[5}R/W(/-*C:?#Ht#rof1(#/urc}@^W8l&');
define('LOGGED_IN_KEY',    '*8DdrvZ5*b/k>Hwiw!we^UbD+=E@V?=9%OkF=8sZ/LvGl&wSapI9x;pn:~K~P-Ow');
define('NONCE_KEY',        ',o{M7-z2?ivD3TZH[k<QD!6XmUu_$(.1Y=5{+})9rmUN68D/k@RQa!BnPT[UsJO<');
define('AUTH_SALT',        '2$(1m-w;-Rx+|8W q>I=[jB+?8b|C*<TH-RZ6&l,i0I2+pgjStw_<eM-seok;b{G');
define('SECURE_AUTH_SALT', '=A$CRbY-eJ{:?Q-%9?F_C`+kOZX}[OWTen|Deht4gu9[d8+`1M!5i-^m][mS)JKz');
define('LOGGED_IN_SALT',   '7_+N+e9&V;iQN]{&@FZCX,AY1]rgnsplc]nfP:itf%@Ebi9e>oZowM`^Wr`iIbs ');
define('NONCE_SALT',       'c=`PF/!rcc7%k&eW>O%[$72[r^RV1 nyJf-VENJa2,OeLz3$+!dU3+mm~,m|0&lx');


$table_prefix = 'wp_';





/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('WP_DEBUG',true);
define('FS_METHOD','direct');
